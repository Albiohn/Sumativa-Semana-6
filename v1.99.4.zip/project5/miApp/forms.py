from django.forms import ModelForm
from .models import micuentatf
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User
from django import forms

class micuentatfForm(ModelForm):
    class Meta:
        model = micuentatf
        fields = ['title', 'description', 'important']

class Registro(UserCreationForm):
    email = forms.EmailField(max_length=100, help_text="Ingrese su correo electrónico")

    class Meta(UserCreationForm.Meta):
        model = User
        fields = ("username", "email", "password1", "password2")