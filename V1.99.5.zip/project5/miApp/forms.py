from django.forms import ModelForm
from .models import micuentatf

class micuentatfForm(ModelForm):
    class Meta:
        model = micuentatf
        fields = ['title', 'description', 'important']

