from miApp import views
from django.urls import path


urlpatterns = [
    
    path('terror/', views.terror, name='terror'),
    path('inicio_sesion_wiki/', views.inicio_sesion_wiki, name='inicio_sesion_wiki'),
    path('', views.index, name='index'),
    path('logout/', views.signout, name='logout'),
    path('micuenta/', views.micuenta, name='micuenta'),
    path('informes_creados/', views.informes_creados, name='informes_creados'),
    path('create_micuentatf/', views.create_micuentatf, name='create_micuentatf'), 
    path('recuperarcontra/', views.recuperarcontra, name='recuperarcontra'),
    path('registrarse_wiki/', views.registrarse_wiki, name='registrarse_wiki'), 
    path('accion/', views.accion, name='accion'),
    path('shooters/', views.shooters, name='shooters'),
    path('aventura/', views.aventura, name='aventura'),
    path('addtocar/<codigo>', views.addtocar, name="addtocar"),
    path('rpg/', views.rpg, name='rpg'),
    path('dropitem/<codigo>', views.dropitem, name="dropitem"),
    path('carrito_compra', views.carrito_compra, name="carrito_compra"),
]   
