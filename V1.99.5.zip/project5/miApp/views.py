from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.forms import UserCreationForm, AuthenticationForm
from django.contrib.auth import login, logout, authenticate
from django.contrib.auth.models import User
from django.db import IntegrityError
from django.utils import timezone
from django.contrib.auth.decorators import login_required
from .forms import micuentatfForm
from .models import *

def registrarse_wiki(request):
    if request.method == 'GET':
        return render(request, 'registrarse_wiki.html', {'form': UserCreationForm()})
    else:
        if request.POST["password1"] == request.POST["password2"]:
            try:
                user = User.objects.create_user(
                    request.POST["username"], password=request.POST["password1"])
                user.save()
                login(request, user)
                return redirect('index')
            except IntegrityError:
                return render(request, 'registrarse_wiki.html', {"form": UserCreationForm, "error": "Username already exists."})
    return render(request, 'registrarse_wiki.html', {"form": UserCreationForm, "error": "Passwords did not match."})
        


def carrito_compra(request):
    context = {"carro":request.session.get("carro", [])}
    user = request.user
    return render(request, 'miApp/carrito_compra.html',  context)

def dropitem(request, codigo):
    carro = request.session.get("carro", [])
    for item in carro:
        if item[0] == codigo:
            if item[4] > 1:
                item[4] -= 1
                item[5] = item[3] * item[4]
                break
            else:
                carro.remove(item)
    request.session["carro"] = carro
    return redirect(to="carrito_compra")


def addtocar(request, codigo):
    producto = Producto.objects.get(codigo=codigo)
    carro = request.session.get("carro", [])
    for item in carro:
        if item[0] == codigo and producto.stock > item[4]:
            item[4] += 1
            item[5] = item[3] * item[4]
            print('1')
            break
        elif item[0] == codigo and producto.stock <= item[4]:
             if producto.tipo == 1:
                return redirect(to="accion")
            
    else:
        carro.append([codigo, producto.detalle, producto.imagen, producto.precio, 1, producto.precio])
        print('2')
    request.session["carro"] = carro
    if producto.tipo == 1:
        return redirect(to="accion")



@login_required
def signout(request):
    logout(request)
    return redirect('index')



   
def inicio_sesion_wiki(request):
    if request.method == 'GET':
        return render(request, 'inicio_sesion_wiki.html', {"form": AuthenticationForm})
    else:
        user = authenticate(
            request, username=request.POST['username'], password=request.POST['password'])
        if user is None:
            return render(request, 'inicio_sesion_wiki.html', {"form": AuthenticationForm, "error": "Username or password is incorrect."})

        login(request, user)
        return redirect('index')
    
@login_required    
def micuenta(request):
    return render(request, 'micuentatf.html')

@login_required
def create_micuentatf(request):
    if request.method == "GET":
        return render(request, 'create_micuentatf.html', {"form": micuentatfForm})
    else:
        try:
            form = micuentatfForm(request.POST)
            new_micuentatf = form.save(commit=False)
            new_micuentatf.user = request.user
            new_micuentatf.save()
            return redirect('micuentatf')
        except ValueError:
            return render(request, 'create_micuentatf.html', {"form": micuentatfForm, "error": "Error creating task."})
        

def accion(request):
    accion = Producto.objects.all()
    return render(request, 'accion.html', {'accion': accion})

@login_required
def informes_creados(request):
    informes_creados = micuentatf.objects.all()
    return render(request, 'informes_creados.html', {"informes_creados": informes_creados})

def terror(request):
    return render(request, 'terror.html')

def shooters(request):
    return render(request, 'shooters.html') 

def aventura(request):
    aventura = Producto.objects.all()
    return render(request, 'aventura.html', {'aventura': aventura})

def rpg(request):
    return render(request, 'rpg.html')







def index(request):
    return render(request, 'index.html')


@login_required
def recuperarcontra(request):
    return render(request, 'recuperarcontra.html')
